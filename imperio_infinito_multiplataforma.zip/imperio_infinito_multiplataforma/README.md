# IMPERIO INFINITO — proyecto multiplataforma

**Base compartida para Android e iPhone mediante Capacitor 8.5.2.** Incluye el juego web V13.2 Mobile Edition dentro de `www/`, configuración inicial y scripts para crear los proyectos nativos.

> Este paquete es un proyecto fuente preparado para compilar. No contiene todavía un APK/AAB firmado ni un IPA firmado, y no es una publicación aprobada por Google Play o App Store.

## Requisitos

- Node.js 22 o superior y npm.
- **Android:** Android Studio 2025.2.1 o posterior, Android SDK Platform 36, Build Tools y JDK recomendado por Android Studio.
- **iPhone:** un Mac con Xcode 26 o posterior y herramientas de línea de comandos. La compilación y firma iOS no se pueden realizar en Windows/Linux.
- Cuentas de desarrollador de Google Play y Apple para publicar.

Capacitor 8 admite Android 7+ e iOS 15+ según su matriz de soporte. Comprueba la documentación de Capacitor y las exigencias de las tiendas antes de publicar.

## Preparar Android

Desde esta carpeta, en terminal:

```bash
npm install
npm run platforms:android
npm run sync
npm run open:android
```

El script configura `compileSdkVersion=36`, `targetSdkVersion=36` y `minSdkVersion=24` cuando encuentra las variables del proyecto generado. Confirma esos valores en Android Studio/Gradle antes de compilar.

En Android Studio:
1. Espera a que termine Gradle Sync.
2. Ejecuta primero en un emulador y después en móviles físicos.
3. Comprueba guardado, cierre forzado, reinicio, rotación, tamaños de pantalla y modo sin conexión.
4. Configura una clave de firma de publicación y guárdala fuera del repositorio.
5. Genera **Build > Generate Signed Bundle / APK > Android App Bundle** para obtener el `.aab`.
6. Sube el AAB a una pista de pruebas internas de Play Console; completa Data safety, clasificación, política de privacidad y ficha.

## Preparar iPhone

En un Mac con Xcode 26 o posterior:

```bash
npm install
npm run platforms:ios
npm run sync
npm run open:ios
```

En Xcode:
1. Abre el workspace generado y selecciona el target `App`.
2. Configura un Bundle Identifier definitivo, equipo de firma y capacidades necesarias.
3. Ejecuta en simulador y en iPhone físico.
4. Configura iconos/splash definitivos y comprueba Safe Areas, persistencia y comportamiento al suspender/reanudar.
5. Archive y valida el build; distribuye mediante TestFlight antes de App Store Connect.

## Actualizar el juego

Sustituye `www/index.html` por la versión aprobada y ejecuta:

```bash
npm run sync
```

No cambies `appId` después de publicar: `com.imperioinfinito.game` es provisional y debe confirmarse antes del primer lanzamiento.

## Estado real de las funciones

- El progreso se guarda localmente en el WebView mediante `localStorage`; no hay cuenta ni sincronización en la nube.
- No se han integrado anuncios, pagos, analítica, backend, clanes ni multijugador.
- La copia de seguridad manual no equivale a una sincronización automática entre dispositivos.
- El arte, icono y capturas incluidos son provisionales y deben sustituirse por recursos finales con derechos confirmados.

## Archivos

- `www/index.html`: juego actual.
- `capacitor.config.json`: identificador y configuración de Capacitor.
- `scripts/configure-android.mjs`: ajuste inicial de API Android.
- `assets/icon-1024.png`: icono provisional de trabajo.
- `docs/RELEASE_CHECKLIST.md`: lista de pruebas y publicación.


## Si solo tienes iPhone: compilación en la nube

El iPhone no puede ejecutar Android Studio, Gradle ni Xcode localmente. La carpeta incluye `.github/workflows/mobile-build-check.yml`: cuando el proyecto esté en un repositorio GitHub y se ejecute el workflow, GitHub Actions compilará un APK de depuración Android y una app de simulador iOS. Los artefactos sirven para comprobar compilación; **no son paquetes firmados para publicar**.

Pasos desde Safari en iPhone:
1. Entra en GitHub y crea un repositorio vacío para el proyecto.
2. Sube el contenido de este ZIP conservando las carpetas `.github`, `scripts`, `www` y `docs`. En GitHub, activa la visualización de archivos ocultos si fuera necesario para `.github`.
3. Abre la pestaña **Actions**, habilita los workflows y ejecuta **Mobile build checks**.
4. Descarga los artefactos desde la ejecución cuando finalice. El APK debug se instala solo con los avisos de seguridad correspondientes; el artefacto iOS de simulador no se instala en un iPhone físico.
5. Para publicar Android hace falta una clave de firma propia y generar un AAB firmado. Para publicar iOS hace falta Apple Developer, certificados/perfiles y un runner macOS que archive y firme para distribución. Nunca compartas claves privadas, contraseñas ni certificados en el chat o en un repositorio público.

### Lo que aún no está hecho
- No se han generado proyectos nativos definitivos ni firmado APK/AAB/IPA.
- No se han ejecutado estos workflows en tu repositorio.
- No se ha probado en un iPhone físico ni en un Android físico.
- El juego conserva guardado local: no hay sincronización entre dispositivos.
- No hay integración real de anuncios, compras, cuentas ni backend.
- El identificador `com.imperioinfinito.game` es provisional; debe confirmarse antes de publicar.
