# Lista de salida — IMPERIO INFINITO

## Ingeniería
- [ ] Instalar dependencias y generar proyectos Android/iOS.
- [ ] Confirmar versiones de Capacitor, SDK, Gradle, Xcode y plugins.
- [ ] Prueba de inicio limpio y actualización desde build anterior.
- [ ] Prueba de guardado/restauración y corrupción de datos.
- [ ] Prueba offline/online, suspensión, reanudación y cierre forzado.
- [ ] Prueba en Android de varios fabricantes y tamaños.
- [ ] Prueba en iPhone físico y varios tamaños de pantalla.
- [ ] Accesibilidad: contraste, VoiceOver/TalkBack, tamaño de texto y objetivos táctiles.
- [ ] Rendimiento, consumo de batería, memoria y calentamiento.
- [ ] Auditoría de seguridad, dependencias y permisos.

## Juego y contenido
- [ ] Verificar todas las rutas de combate, jefes, talentos, prestigio y recompensas.
- [ ] Verificar equilibrio de progresión y economía con partidas nuevas y avanzadas.
- [ ] Revisar los seis idiomas de principio a fin.
- [ ] Confirmar que ninguna recompensa anunciada o compra es ficticia.
- [ ] Validar guardado local y explicar claramente que no hay nube.
- [ ] Sustituir recursos provisionales por arte original final.

## Google Play
- [ ] Confirmar target API vigente en Play Console (la documentación oficial indica API 36 para nuevas apps desde 31-08-2026).
- [ ] Generar y firmar AAB de release.
- [ ] Play App Signing, ficha, icono 512x512 y capturas.
- [ ] Política de privacidad pública y formulario Data safety correcto.
- [ ] Clasificación de contenido, audiencia y declaraciones de anuncios.
- [ ] Prueba interna/cerrada y resolución de incidencias.

## App Store
- [ ] Compilar con versión de Xcode/SDK exigida el día del envío (Apple indica Xcode 26 + SDK iOS 26 desde 28-04-2026).
- [ ] Bundle ID, certificados, perfiles y App Store Connect.
- [ ] Icono y capturas de todos los tamaños requeridos.
- [ ] Política de privacidad, App Privacy y clasificación de edad.
- [ ] TestFlight, pruebas en dispositivos y revisión de Apple.

## No declarar listo hasta que
- [ ] Los builds release estén generados, firmados y probados.
- [ ] Las pruebas físicas y los formularios de tienda estén completos.
- [ ] Las tiendas acepten la revisión.


## Compilación desde iPhone mediante GitHub Actions
- [ ] Subir todas las carpetas del ZIP a un repositorio GitHub (incluida `.github`).
- [ ] Activar Actions y ejecutar `Mobile build checks`.
- [ ] Revisar logs de Gradle y Xcode; no basta con que el workflow aparezca verde si faltan pruebas.
- [ ] Descargar APK debug e instalarlo en un Android físico para pruebas.
- [ ] Preparar firma de Android y AAB release en un flujo separado.
- [ ] Configurar firma iOS con Apple Developer y generar archive de distribución/TestFlight en macOS.
