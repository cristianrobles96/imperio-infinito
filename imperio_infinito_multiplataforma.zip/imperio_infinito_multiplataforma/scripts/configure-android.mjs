import fs from 'node:fs';
import path from 'node:path';
const file = path.resolve('android/variables.gradle');
if (!fs.existsSync(file)) {
  console.error('No se encuentra android/variables.gradle. Ejecuta este script después de "npx cap add android".');
  process.exit(1);
}
let s = fs.readFileSync(file, 'utf8');
for (const [key, value] of [['compileSdkVersion','36'],['targetSdkVersion','36'],['minSdkVersion','24']]) {
  const re = new RegExp(`(${key}\\s*=\\s*)\\d+`);
  if (re.test(s)) s = s.replace(re, `$1${value}`);
  else console.warn(`No se encontró ${key}; revisa manualmente variables.gradle`);
}
fs.writeFileSync(file, s);
console.log('Android configurado: compileSdk 36, targetSdk 36, minSdk 24. Verifica de nuevo el requisito de Play Console al publicar.');
