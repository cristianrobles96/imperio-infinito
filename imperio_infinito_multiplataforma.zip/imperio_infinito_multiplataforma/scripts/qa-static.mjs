import fs from 'node:fs';
import path from 'node:path';
const htmlPath = path.resolve('www/index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
const errors = [];
const ids = [...html.matchAll(/\bid=["']([^"']+)["']/g)].map(m=>m[1]);
const duplicates = [...new Set(ids.filter((id,i)=>ids.indexOf(id)!==i))];
if (duplicates.length) errors.push(`IDs duplicados: ${duplicates.join(', ')}`);
if (!/<meta[^>]+name=["']viewport["'][^>]+viewport-fit=cover/i.test(html)) errors.push('Falta viewport-fit=cover');
if (!/<title>[^<]+<\/title>/i.test(html)) errors.push('Falta título HTML');
const scripts = [...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)].map(m=>m[1]).filter(s=>s.trim());
for (let i=0;i<scripts.length;i++) {
  const tmp=path.resolve(`.qa-inline-${i}.js`);
  fs.writeFileSync(tmp,scripts[i]);
  const {spawnSync}=await import('node:child_process');
  const r=spawnSync(process.execPath,['--check',tmp],{encoding:'utf8'});
  fs.rmSync(tmp,{force:true});
  if(r.status!==0) errors.push(`JavaScript inline ${i+1}: ${r.stderr||r.stdout}`);
}
for (const f of ['capacitor.config.json','www/manifest.webmanifest']) {
  try { JSON.parse(fs.readFileSync(path.resolve(f),'utf8')); } catch(e) { errors.push(`${f}: ${e.message}`); }
}
if (!fs.existsSync(path.resolve('www/sw.js'))) errors.push('Falta service worker');
console.log(`IDs HTML: ${ids.length}; scripts inline: ${scripts.length}`);
if(errors.length){console.error(errors.join('\n'));process.exit(1)}
console.log('QA estático superado. Esto no sustituye pruebas en dispositivos ni compilación nativa.');
