# Control de fases 1–21

Este control registra la integración del código acumulado, sin convertir tareas preparatorias en funciones activas.

| Fases | Área | Estado en este paquete |
|---|---|---|
| 1–10 | Base del juego, diseño, mundos, idiomas, Santuario y reglas iniciales | Integradas en la base acumulada |
| 11 | Calidad, validación de importación/exportación y accesibilidad de movimiento | Integrada |
| 12 | Arte de batalla de Robles y caché de recursos | Integrada |
| 13 | Efectos y lógica de combate/jefes | Integrada; requiere prueba en navegador real |
| 14 | Progresión, equipo, mascotas y misiones | Integrada |
| 15 | Copia local, recuperación y reinicio limpio | Integrada; recuperación real debe probarse en dispositivo |
| 16 | Preparación de conexión online y contrato de backend | Preparación integrada; backend real pendiente |
| 17 | Reglas y configuración de monetización | Preparación integrada; SDK de anuncios y Billing pendientes |
| 18 | Capacitor y guías de Android | Preparación integrada; APK/AAB aún no generado |
| 19 | Auditoría, privacidad y ficha de tienda en borrador | Documentación integrada; revisión y pruebas de publicación pendientes |
| 20 | Estabilidad de partida, normalización y ciclo de vida | Integrada; requiere prueba funcional en navegador y Android |
| 21 | Pruebas automáticas de estructura y reglas críticas | Integradas; son comprobaciones estáticas, no sustituyen pruebas interactivas |

## Próximas acciones técnicas
1. Ejecutar `npm run release:check` antes de cada compilación.
2. Probar interactivamente guardado, importación, combate, Santuario y cambio de idioma en navegador y Android.
3. Añadir el proyecto a GitHub en una rama nueva, conservando `main` y el sitio anterior.
4. Configurar Codemagic para compilar un APK de prueba primero.
5. Instalar y probar el APK en Redmi Note 13 Pro 5G.
6. Solo tras corregir errores, generar AAB firmado y configurar Play Console.

## Fase 22 — pruebas funcionales y casos límite
- [x] Contratos de importación/exportación y validación de datos.
- [x] Reglas de fichas, puertas, jefes y final del Santuario.
- [x] Bloqueo seguro de anuncios y compras sin SDK nativo.
- [x] Pruebas añadidas a `release:check`.
- [ ] Pruebas interactivas en navegador y dispositivo Android real.

| 22 | Pruebas de contratos funcionales y casos límite | Integradas; automatizadas, no equivalen a interacción real |
| 23 | Auditoría del paquete móvil, recursos locales, metadatos PWA y accesibilidad básica | Integrada; auditoría estática, falta prueba en navegador/dispositivo |

## Fase 23 — auditoría del paquete móvil
- [x] Verificación de viewport y metadatos móviles.
- [x] Verificación del manifest y nombre de aplicación.
- [x] Verificación de icono y arte local de Robles.
- [x] Comprobación de movimiento reducido y foco visible.
- [x] Comprobación de referencias a recursos locales.
- [x] Incorporada a `npm run release:check`.
- [ ] Prueba visual real en Redmi Note 13 Pro 5G.
