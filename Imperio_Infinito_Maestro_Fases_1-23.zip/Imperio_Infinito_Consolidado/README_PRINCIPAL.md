# IMPERIO INFINITO — proyecto consolidado

Esta carpeta reúne en una sola versión acumulativa el trabajo de las fases 1–19. La versión web de juego está en `www/index.html`; no se deben mezclar ZIP antiguos encima de esta carpeta ni subir fases por separado.

## Contenido acumulado
- Base incremental/RPG, protagonista Robles, mundos y selección de idioma.
- Mejoras de calidad, exportación/importación y validación del guardado.
- Arte de batalla integrado (`www/assets/robles-battle.webp`), combate y efectos de jefes.
- Equipo, mascotas, misiones y progresión del Santuario del Eclipse.
- Copia de seguridad local, recuperación y reinicio de partida.
- Preparación de interfaces/configuración para online y monetización; **no son servicios activos**.
- Configuración de Capacitor y documentación para preparar Android.
- Auditoría previa a publicación y borradores de ficha/privacidad.

## Estado real de publicación
Este proyecto todavía no es una versión lista para Google Play. No incluye un AAB firmado ni una compilación Android probada en el Redmi. No hay backend online contratado/conectado, ni anuncios recompensados reales ni compras activas. Las configuraciones y documentos de esas áreas son preparación, no integraciones terminadas.

## Comprobaciones locales
Desde esta carpeta, con Node.js instalado:

```bash
npm install
npm run release:check
```

Para generar la estructura Android:

```bash
npm run android:prepare
```

Después hay que compilar y probar con Android SDK/Gradle, o usar un servicio CI compatible. No iniciar compilaciones de pago hasta revisar el repositorio y la configuración.

## Seguridad y preservación
- Mantener la versión publicada de prueba separada hasta validar la nueva.
- No incluir contraseñas, tokens, claves de firma ni secretos en Git.
- Antes de sustituir el repositorio, crear una rama/copia de seguridad.

## Última integración: Fase 20
Se reforzó la recuperación de partidas, la normalización de vida del jefe y Santuario, el reinicio completo y el registro de caché offline para que no interfiera con Capacitor nativo. Consulta `docs/FASE20_ESTABILIDAD.md` y `CONTROL_DE_FASES.md`.
