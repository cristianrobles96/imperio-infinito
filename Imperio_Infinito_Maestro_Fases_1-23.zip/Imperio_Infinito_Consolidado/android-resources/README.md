# Recursos de marca Android

- Nombre visible: Imperio Infinito
- ID de aplicación: `com.imperioinfinitostudio.imperioinfinito`
- Icono vectorial base: `www/icon.svg`
- La generación del proyecto Android con Capacitor crea los recursos nativos iniciales.
- Antes de publicar, generar iconos PNG adaptativos en los tamaños exigidos por Android y revisar el recorte en fondos claros y oscuros.

No usar una clave de firma de producción compartida ni subirla al repositorio. Guardar el keystore y sus contraseñas en un lugar seguro con copia de respaldo.
