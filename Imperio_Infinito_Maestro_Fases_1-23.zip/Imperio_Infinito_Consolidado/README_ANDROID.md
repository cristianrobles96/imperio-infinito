# IMPERIO INFINITO — Android (fase 18)

Esta es la base de empaquetado Android con Capacitor. No es todavía un APK/AAB listo para instalar o publicar.

## Inicio rápido
- Windows: doble clic en `scripts/preparar-android.bat`.
- macOS/Linux: `bash scripts/preparar-android.sh`.

Después abre la carpeta `android` en Android Studio. Consulta `docs/ANDROID_BUILD_GUIDE.md`.

## Comprobación web
Desde la carpeta del proyecto: `npm run web:check`.
