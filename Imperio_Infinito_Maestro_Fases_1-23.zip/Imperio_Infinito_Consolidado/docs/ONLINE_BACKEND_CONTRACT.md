# Imperio Infinito — contrato de backend online

## Estado de esta fase

El cliente queda preparado para detectar un backend HTTPS y consultar una clasificación pública real. El backend **no está desplegado ni conectado** en esta entrega. `www/online-config.json` mantiene `enabled: false`; por ello la interfaz informa claramente de que no hay conexión y no inventa jugadores.

## Endpoints previstos

- `GET /health` → `{"status":"ok"}`
- `GET /v1/leaderboard?limit=10` → `{"entries":[{"displayName":"Robles","level":10,"victories":25}]}`

El cliente solo acepta una URL HTTPS. Los nombres se escapan antes de insertarse en la interfaz y se limitan a 18 caracteres. La clasificación pública no debe devolver correo, identificadores privados ni otros datos personales.

## Próxima integración segura

1. Elegir proveedor/backend y crear proyecto bajo la cuenta del titular.
2. Configurar autenticación (tokens de corta duración; nunca claves privadas o `service_role` dentro de la app).
3. Crear perfiles, guardados en nube y clasificación con validación en servidor.
4. Verificar propiedad de la partida y evitar que el cliente pueda asignarse oro, gemas, victorias o compras.
5. Añadir políticas de privacidad, borrado/exportación de cuenta, límites de peticiones y protección contra trampas.
6. Activar `enabled: true` y poner `apiBaseUrl` únicamente cuando los endpoints estén desplegados y probados.

## Modelo mínimo de datos sugerido

- `profiles`: `user_id` (UUID), `display_name`, `created_at`, `updated_at`.
- `player_saves`: `user_id`, `save_version`, `payload`, `updated_at`.
- `leaderboard`: vista calculada en servidor a partir de estadísticas verificadas; nunca aceptar puntuaciones arbitrarias del cliente.
- `guilds` / `guild_members`: reservar para una iteración posterior con permisos y moderación.

No incluir secretos de backend en archivos web, APK o repositorios públicos.
