# Política de privacidad — BORRADOR PARA ADAPTAR

**No publicar este texto sin completarlo y verificarlo.** La versión definitiva debe identificar al responsable legal, dirección y contacto, describir los datos realmente recogidos, finalidades, bases jurídicas, conservación, destinatarios/proveedores, transferencias internacionales, derechos y forma de ejercerlos. Debe coincidir con el comportamiento de la aplicación y con los SDK que finalmente se integren.

## Responsable
- Responsable: [nombre o entidad legal]
- Dirección: [dirección de contacto]
- Correo de privacidad: [correo de contacto]

## Datos tratados
[Describir únicamente los datos que la versión publicada trate realmente: datos de cuenta, progreso sincronizado, identificadores técnicos, diagnósticos, compras, publicidad, etc. Si una función no está activa, no afirmar que se usa.]

## Finalidades y proveedores
[Enumerar cada finalidad y el proveedor/SDK correspondiente, incluyendo autenticación, alojamiento, analítica, anuncios y pagos si se incorporan. Indicar qué datos recibe cada proveedor.]

## Conservación y derechos
[Indicar plazos concretos o criterios de conservación, cómo solicitar acceso, rectificación, supresión, oposición, limitación y portabilidad cuando proceda, y cómo reclamar ante la autoridad competente.]

## Menores y cambios
[Definir el público previsto y las medidas aplicables a menores según la clasificación y legislación pertinentes. Indicar cómo se comunicarán cambios de esta política.]

Fecha de entrada en vigor: [fecha]
