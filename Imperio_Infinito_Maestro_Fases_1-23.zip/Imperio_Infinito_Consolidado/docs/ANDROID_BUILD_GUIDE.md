# Imperio Infinito — fase 18: preparación Android

## Lo que queda preparado
- Configuración Capacitor con ID estable `com.imperioinfinitostudio.imperioinfinito`.
- Nombre de aplicación y carpeta web `www` configurados.
- Scripts para generar/sincronizar el proyecto Android en Windows y macOS/Linux.
- Comandos de compilación debug y AAB release documentados.
- Recursos y lista de comprobación para icono, firma y publicación.

## Lo que NO se ha generado ni probado aquí
Este paquete todavía **no contiene un APK ni un AAB firmado**. En este entorno no está instalado Android SDK/Android Studio ni Gradle, por lo que no es posible compilar ni probar en emulador. No presentar este paquete como una aplicación ya lista para Play Store.

## Requisitos en un ordenador
1. Instalar Node.js LTS, JDK compatible y Android Studio.
2. Instalar Android SDK Platform y Build-Tools recomendados por Android Studio.
3. En Windows ejecutar `scripts\\preparar-android.bat`; en macOS/Linux ejecutar `scripts/preparar-android.sh`.
4. Abrir la carpeta `android` con Android Studio y esperar a que Gradle sincronice.
5. Probar en un dispositivo Android físico: inicio, navegación, guardado, importación/exportación, audio, rotación, suspensión y reanudación.
6. Corregir errores antes de crear el paquete de publicación.

## Compilar
- APK de depuración: desde Android Studio, Build > Build APK(s), o `npm run android:debug` en Windows.
- AAB de publicación: Android Studio > Build > Generate Signed Bundle / APK > Android App Bundle, o `npm run android:release` después de configurar la firma.
- Para publicar, usar un upload key propio, activar Play App Signing y conservar una copia segura del keystore.

## Antes de Play Console
- Verificar `applicationId` definitivo; no cambiarlo después de publicar.
- Establecer `versionCode` incremental y `versionName`.
- Generar iconos adaptativos y splash final.
- Revisar permisos: no solicitar ninguno que no sea necesario.
- Añadir política de privacidad y completar Data safety, clasificación por edades, anuncios y declaraciones de contenido.
- Los anuncios y compras siguen pendientes de integración nativa real según `MONETIZATION_NATIVE_INTEGRATION.md`.
- Las cuentas y nube siguen pendientes de backend real según `ONLINE_BACKEND_CONTRACT.md`.
