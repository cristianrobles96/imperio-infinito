# Borrador de ficha de Google Play (no publicar hasta validar)

Nombre: Imperio Infinito
Desarrollador visible previsto: Imperio Infinito Studio

Descripción breve (borrador):
Conviértete en Robles, mejora tu héroe y explora mundos de fantasía llenos de enemigos y jefes.

Descripción larga (borrador):
Embárcate en una aventura incremental de fantasía. Lucha contra criaturas, derrota guardianes, mejora tu equipo, reúne mascotas y descubre nuevos mundos. Avanza con Robles, completa misiones y desafía el Santuario del Eclipse.

Características que solo deben anunciarse si están verificadas en la versión publicada:
- Cinco idiomas: español, inglés, francés, alemán y portugués.
- Guardado y recuperación de progreso.
- Anuncios recompensados opcionales en el Santuario del Eclipse.
- Compras integradas.
- Cuentas, clasificación mundial, alianzas y guardado en la nube.

No afirmar multijugador, funciones online, compras o anuncios activos mientras no estén integrados y probados. Añadir capturas auténticas de la app final, icono, gráfico de funciones y clasificación por edades cuando estén disponibles.
