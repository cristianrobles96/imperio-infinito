# Fase 22 — contratos funcionales y casos límite

## Objetivo
Ampliar la batería automatizada con verificaciones de las reglas de importación/exportación, restauración de copias, reinicio, economía del Santuario y bloqueo seguro de monetización.

## Cobertura añadida
- Archivo de guardado JSON y límite de tamaño al importar.
- Rechazo de datos malformados, números no finitos y valores extremos.
- Lista permitida de idiomas.
- Existencia de restauración de copia y limpieza de guardados nuevos al reiniciar.
- Una ficha por ataque y una ficha por vídeo de demostración.
- Avance de puerta sin ficha extra y cierre al terminar el nivel 100.
- Vida del enemigo limitada a cero y jefes cada cinco niveles.
- Anuncios y compras bloqueados hasta que exista SDK nativo configurado.

## Ejecución
```bash
npm run game:functional-test
npm run release:check
```

## Resultado y límites
Estas pruebas inspeccionan automáticamente el código y sus condiciones de seguridad. No ejecutan todavía la interfaz en un navegador real, no prueban el almacenamiento real del dispositivo y no sustituyen una prueba física en el Redmi. Esas validaciones siguen siendo obligatorias antes de publicar.
