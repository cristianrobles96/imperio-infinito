# Fase 21 — pruebas automáticas de contratos del juego

## Objetivo
Añadir una batería repetible de comprobaciones estáticas para detectar roturas básicas antes de sincronizar Capacitor o generar una compilación Android.

## Comprobaciones incluidas
- Sintaxis de todos los bloques JavaScript embebidos.
- Correspondencia entre navegación y contenedores de vistas.
- Existencia de controles críticos de batalla, ajustes y guardado.
- Presencia de los cinco idiomas previstos (español, inglés, francés, alemán y portugués).
- Pausa del combate automático cuando la aplicación está en segundo plano.
- Reglas del Santuario: consumo de ficha por ataque, ficha por vídeo de prueba, avance de puerta sin ficha adicional y finalización en nivel 100.
- Confirmación antes de reiniciar y existencia de copia de seguridad local.
- Aviso explícito de que los anuncios de esta versión son simulados.

## Cómo ejecutar
```bash
npm run game:test
npm run release:check
```

## Límites
Son pruebas estáticas de contratos y estructura. No simulan toques reales, almacenamiento del navegador, reproducción de anuncios, compras, red, ni rendimiento. Esas pruebas siguen pendientes en navegador y en el Redmi Note 13 Pro 5G.
