# Imperio Infinito — Fase 19: auditoría previa a Google Play

## Estado honesto
Esta fase prepara la revisión y los materiales de publicación. **No certifica que el juego esté listo para publicarse**: todavía no se ha compilado un AAB firmado ni se ha probado en dispositivos Android físicos. Tampoco están conectados un backend real, Google Play Billing ni un SDK de anuncios recompensados.

## Comprobaciones realizadas en este paquete
- `node scripts/check-inline.js`: sintaxis de los scripts JavaScript incrustados.
- Recuento de identificadores HTML y detección de duplicados.
- Validación de JSON de configuración (`package.json`, `capacitor.config.json`, manifiesto y configuraciones online/monetización).
- Integridad del ZIP final.

Estas pruebas estáticas no sustituyen pruebas de interfaz, seguridad, rendimiento, accesibilidad ni pruebas en Android.

## Bloqueos antes de publicar
1. Instalar Node.js LTS, JDK y Android Studio/SDK en un ordenador.
2. Generar el proyecto nativo con `npm run android:prepare` y sincronizarlo.
3. Probar en varios móviles Android: instalación limpia, navegación, cinco idiomas, guardado/restauración, rotación, suspensión/reanudación, modo sin conexión y rendimiento.
4. Corregir los fallos encontrados y ejecutar pruebas de regresión.
5. Configurar firma de publicación, `versionCode` y `versionName`; generar AAB firmado.
6. Integrar y probar realmente anuncios recompensados y compras antes de declarar esas funciones en la ficha.
7. Si se activan cuentas, nube o clasificación online, desplegar backend, configurar autenticación, reglas de acceso, protección de datos y moderación.
8. Publicar una política de privacidad que describa exactamente los datos y SDK que se usen; completar el formulario Data safety y las declaraciones de anuncios/contenido.
9. Completar clasificación por edades, acceso a la app para revisores, ficha de tienda, capturas reales y pruebas internas/cerradas requeridas por Play Console.
10. Revisar los requisitos vigentes de Play Console en el momento de enviar la aplicación.

## Criterio de salida
No marcar como “lista para Play Store” hasta que exista un AAB firmado, se haya instalado y probado en dispositivos reales, se hayan resuelto los bloqueos anteriores y Play Console acepte la revisión.
