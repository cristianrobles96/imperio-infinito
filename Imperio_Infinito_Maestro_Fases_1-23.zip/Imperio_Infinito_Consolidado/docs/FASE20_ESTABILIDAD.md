# Fase 20 — Estabilidad de partida y ciclo de vida

## Cambios integrados
- Normalización de salud del jefe principal al recuperar una partida, evitando valores negativos o superiores al máximo.
- Normalización de salud y recursos del Santuario y del modo especial al cargar una partida antigua o dañada parcialmente.
- El récord personal de enemigos nunca queda por debajo del progreso actual.
- Reinicio completo incluye todos los campos del Santuario, modo especial y versión de guardado.
- El service worker solo se registra en navegador web seguro; no se registra dentro de Capacitor nativo.
- Se incrementó la versión de caché offline para que los navegadores no mantengan archivos antiguos tras la actualización.

## Verificación de esta fase
- Sintaxis del JavaScript inline.
- JSON de configuración y paquete.
- Identificadores HTML duplicados.
- Existencia de los recursos locales referenciados.
- Integridad del paquete ZIP.

Estas comprobaciones son estáticas. La restauración real y el comportamiento de suspensión/reanudación deben probarse en navegador y dispositivo Android.
