# Imperio Infinito — fase 17: monetización

## Estado real
Esta fase entrega el contrato y el puente JavaScript para integrar monetización nativa. **No hay todavía anuncios reales ni compras habilitadas.** No se han añadido SDKs ni credenciales y los botones premium siguen deshabilitados. El puente falla de forma cerrada si el plugin nativo no existe.

## Anuncios recompensados
Implementar un plugin nativo Android con `window.II_NATIVE_MONETIZATION.showRewarded(placement)` y devolver resultado solo tras el callback de recompensa verificada del SDK. Placements permitidos: `eclipse_ticket` y `eclipse_gate`.
- `eclipse_ticket`: conceder exactamente 1 ficha por una impresión completada y validada.
- `eclipse_gate`: desbloquear el siguiente nivel; nunca conceder ficha adicional.
- Cerrar, fallar, no cargar o saltar el anuncio no concede recompensa.
- No mostrar anuncios forzados en campaña.

## Compras Google Play
Implementar `window.II_NATIVE_MONETIZATION.purchase(productId)` con Google Play Billing Library. Usar IDs de `www/monetization-config.json`, validar compra y estado con backend antes de conceder contenido, gestionar acknowledge/consume, restauración y reembolsos. No confiar en resultados enviados solo desde JavaScript.

## Pendiente antes de activar
1. Crear productos y precios definitivos en Play Console.
2. Elegir y configurar SDK de anuncios y consentimiento/privacidad.
3. Implementar plugin Capacitor Android y verificación server-side.
4. Probar compras de prueba, cancelaciones, fallos, reembolsos y anuncios sin conexión.
5. Añadir política de privacidad, declaración de anuncios y formularios de seguridad de datos.
6. No activar anuncios ni pagos en web/Netlify.

## Contrato del puente
El frontend expone `II_MONETIZATION.isReady()`, `showRewarded(placement)` y `purchase(productId)`. Sin plugin nativo configurado, ambas acciones rechazan la operación: no hay simulación de éxito ni concesión de recompensas.
