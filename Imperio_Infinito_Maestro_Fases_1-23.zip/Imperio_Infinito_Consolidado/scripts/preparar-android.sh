#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v node >/dev/null || { echo 'Instala Node.js LTS'; exit 1; }
command -v java >/dev/null || { echo 'Instala JDK compatible'; exit 1; }
npm install
if [[ ! -f android/settings.gradle ]]; then npx cap add android; fi
npx cap sync android
echo 'Proyecto Android preparado. Ábrelo con Android Studio.'
