const fs = require('fs');
const path = require('path');
const htmlPath = path.join(__dirname, '..', 'www', 'index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
const scripts = [...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)]
  .map(m => m[1]).filter(s => s.trim());
for (const [i, source] of scripts.entries()) {
  new Function(source);
  console.log(`OK: inline script ${i + 1} parses`);
}
if (!scripts.length) console.log('No inline scripts found.');
