const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'www/manifest.webmanifest'), 'utf8'));
let passed = 0;
function check(ok, label) { if (!ok) throw new Error(`FALLO: ${label}`); passed++; console.log(`OK: ${label}`); }

check(/<meta[^>]+name=["']viewport["'][^>]+content=["'][^"']*width=device-width/i.test(html), 'viewport adaptable a pantallas móviles');
check(/<meta[^>]+name=["']theme-color["']/i.test(html), 'color de interfaz móvil definido');
check(/<meta[^>]+name=["']apple-mobile-web-app-capable["']/i.test(html), 'metadatos de modo web-app presentes');
check(manifest.display === 'standalone', 'manifest configurado en modo standalone');
check(manifest.name === 'Imperio Infinito' && manifest.short_name === 'Imperio Infinito', 'nombre de aplicación coherente');
check(fs.existsSync(path.join(root, 'www', 'icon.svg')), 'icono SVG del juego incluido');
check(fs.existsSync(path.join(root, 'www', 'assets', 'robles-battle.webp')), 'arte de batalla de Robles incluido');
check(/prefers-reduced-motion/.test(html), 'respeto por preferencia de movimiento reducido');
check(/:focus-visible/.test(html), 'estados de foco visibles para navegación accesible');
check(/touch-action\s*:\s*manipulation|tap-highlight-color/.test(html), 'estilos de interacción táctil presentes');

// Check local file references in HTML/CSS without treating external URLs as local assets.
const refs = new Set();
for (const m of html.matchAll(/(?:src|href)=["']([^"']+)["']/gi)) {
  const value = m[1].trim();
  if (!value || /^(?:https?:|data:|#|mailto:|tel:|javascript:)/i.test(value)) continue;
  if (/\.(?:css|js|svg|png|jpe?g|webp|woff2?|mp3|ogg)(?:\?|$)/i.test(value)) refs.add(value.split('?')[0]);
}
for (const ref of refs) {
  const clean = ref.replace(/^\.\//, '').replace(/^\//, '');
  check(fs.existsSync(path.join(root, 'www', clean)), `recurso local encontrado: ${clean}`);
}
console.log(`\nRESULTADO: ${passed}/${passed} auditorías de paquete móvil superadas.`);
console.log('LÍMITE: auditoría estática; no prueba ejecución real, rendimiento ni compatibilidad física.');
