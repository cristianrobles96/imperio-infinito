const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const files = [
  'package.json', 'capacitor.config.json', 'www/manifest.webmanifest',
  'www/online-config.json', 'www/monetization-config.json'
];
for (const file of files) {
  JSON.parse(fs.readFileSync(path.join(root, file), 'utf8'));
  console.log(`OK: ${file}`);
}
const html = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');
const ids = [...html.matchAll(/\bid=["']([^"']+)["']/g)].map(m => m[1]);
const duplicates = ids.filter((id, i) => ids.indexOf(id) !== i);
if (duplicates.length) throw new Error(`Duplicate HTML ids: ${[...new Set(duplicates)].join(', ')}`);
console.log(`OK: ${ids.length} HTML ids; no duplicates`);
