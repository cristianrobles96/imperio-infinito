const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');
const assert = (condition, message) => { if (!condition) throw new Error(message); console.log(`OK: ${message}`); };

// The embedded JavaScript must parse before checking gameplay contracts.
const scripts = [...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)].map(m => m[1]).filter(s => s.trim());
assert(scripts.length > 0, 'el juego contiene JavaScript');
for (const [i, source] of scripts.entries()) new Function(source);
assert(true, 'todos los bloques JavaScript pasan el análisis sintáctico');

const ids = new Set([...html.matchAll(/\bid=["']([^"']+)["']/g)].map(m => m[1]));
const views = [...html.matchAll(/data-view=["']([^"']+)["']/g)].map(m => m[1]);
for (const view of views) assert(ids.has(`${view}View`), `la vista ${view} tiene contenedor HTML`);
for (const id of ['attackBtn','skillBtn','autoBtn','language','nameInput','importFile','bossEmoji','landscape']) assert(ids.has(id), `existe el control ${id}`);

const source = scripts.join('\n');
for (const lang of ['es','en','fr','de','pt']) assert(source.includes(`${lang}:`), `idioma ${lang} está definido`);
assert(/if\(document\.hidden\)return/.test(source), 'el combate automático se pausa cuando la app queda en segundo plano');
assert(/eclipseTickets\+\+/.test(source), 'el vídeo de prueba concede una ficha del Santuario');
assert(/S\.eclipseLevel\+\+/.test(source) && /S\.eclipseGate=false/.test(source), 'la puerta del jefe avanza de nivel');
const monetization = JSON.parse(fs.readFileSync(path.join(root, 'www/monetization-config.json'), 'utf8'));
assert(monetization.rewardedPlacements.eclipse_gate.extraTicket === false, 'la configuración de puerta no concede ficha adicional');
assert(/if\(n===100\)\{S\.eclipseComplete=true/.test(source), 'el nivel 100 marca el Santuario como completado');
assert(/S\.eclipseTickets--/.test(source), 'cada ataque del Santuario consume una ficha');
assert(/confirm\('¿Reiniciar solo esta partida nueva\?/.test(source), 'el reinicio requiere confirmación');
assert(/iiAscensionBackup/.test(source), 'existe mecanismo de copia local de seguridad');
assert(/No se reproducirá ningún vídeo real|no se reproducirá ningún vídeo real/i.test(source), 'el anuncio de demostración se identifica como simulado');

console.log('\nRESULTADO: contratos estáticos del juego superados. Esto no sustituye las pruebas interactivas en navegador ni en Android.');
