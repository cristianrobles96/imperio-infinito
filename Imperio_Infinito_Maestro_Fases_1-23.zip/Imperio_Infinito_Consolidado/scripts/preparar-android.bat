@echo off
setlocal
cd /d "%~dp0.."
echo =============================================
echo IMPERIO INFINITO - Preparacion Android
echo =============================================
where node >nul 2>nul || (echo ERROR: Instala Node.js LTS y vuelve a intentarlo.& pause & exit /b 1)
where java >nul 2>nul || (echo ERROR: Instala JDK 17 o compatible con Android Gradle Plugin.& pause & exit /b 1)
call npm install || (echo ERROR: No se pudieron instalar las dependencias.& pause & exit /b 1)
if not exist android\settings.gradle call npx cap add android || (echo ERROR: Capacitor no pudo crear el proyecto Android.& pause & exit /b 1)
call npx cap sync android || (echo ERROR: No se pudo sincronizar Android.& pause & exit /b 1)
echo Proyecto Android preparado. Abre android\ con Android Studio.
pause
