const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');
const scripts = [...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)].map(m => m[1]).filter(s => s.trim());
const source = scripts.join('\n');
let passed = 0;
function check(ok, label) { if (!ok) throw new Error(`FALLO: ${label}`); passed++; console.log(`OK: ${label}`); }

// Save/export/import safety contracts.
check(source.includes("a.download='imperio-infinito-partida.json'"), 'exportación genera un archivo de partida JSON');
check(/file\.size>250000/.test(source), 'importación limita el tamaño del archivo');
check(/!x\|\|typeof x!=='object'\|\|Array\.isArray\(x\)/.test(source), 'importación rechaza estructuras no válidas');
check(/!Number\.isFinite\(x\.gold\)/.test(source) && /!Number\.isFinite\(x\.level\)/.test(source), 'importación rechaza oro o nivel no finitos');
check(/x\.gold>1e15/.test(source) && /x\.level>10000/.test(source), 'importación limita valores extremos');
check(/\['es','en','fr','de','pt'\]\.includes\(x\.language\)/.test(source), 'importación solo acepta los cinco idiomas admitidos');
check(/iiAscensionBackup/.test(source) && /function restoreBackup\(/.test(source), 'existe ruta explícita para restaurar copia local');
check(/localStorage\.removeItem\('iiAscensionSave'\)/.test(source) && /localStorage\.removeItem\('iiAscensionBackup'\)/.test(source), 'reinicio elimina los guardados de la partida nueva');

// Sanctuary edge cases and exact economy rules.
check(/S\.eclipseTickets--/.test(source), 'cada ataque descuenta exactamente una ficha');
check(/S\.eclipseTickets\+\+/.test(source), 'cada vídeo de prueba concede una ficha');
check(/S\.eclipseLevel\+\+/.test(source), 'el desbloqueo de puerta avanza un nivel');
check(/S\.eclipseLevel>=100/.test(source) && /S\.eclipseComplete=true/.test(source), 'el Santuario se cierra al completar el nivel 100');
check(/S\.eclipseGate\|\|S\.eclipseComplete/.test(source), 'se bloquea el ataque durante la puerta y tras completar');
check(/S\.eclipseHp=Math\.max\(0,S\.eclipseHp-d\)/.test(source), 'la vida del enemigo no baja de cero');
check(/eclipseLevel\(\)%5===0/.test(source), 'los jefes aparecen cada cinco niveles');

// Native monetization must fail closed until native SDK is configured.
check(/REWARDED_ADS_NOT_CONFIGURED/.test(source), 'los anuncios no simulan una recompensa real sin SDK nativo');
check(/BILLING_NOT_CONFIGURED/.test(source), 'las compras se bloquean si Billing no está configurado');
check(/No se reproducirá ningún vídeo real|no se reproducirá ningún vídeo real/i.test(source), 'la recompensa de demostración se identifica como simulada');

console.log(`\nRESULTADO: ${passed}/${passed} contratos funcionales de seguridad superados.`);
console.log('LÍMITE: son verificaciones automatizadas del código y sus condiciones; no sustituyen la interacción real en navegador o Android.');
